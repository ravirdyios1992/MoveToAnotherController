//
//  ViewController.h
//  MoveToAnotherController
//
//  Created by Pramodkumar kandukuru on 5/19/17.
//  Copyright © 2017 Pramodkumar kandukuru. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

